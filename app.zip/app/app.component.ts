import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'demo_project';

name:string="in this yerr"
testValue="suchendra singh"
data=10;

updatedChild(){

this.data = Math.floor(Math.random()*10)

}


}
