import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable, Subscriber, Subscription } from 'rxjs';
import { TimeInterval, timeInterval } from 'rxjs/internal/operators/timeInterval';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.scss']
})
export class ReactiveFormComponent implements OnInit {

reactiveForm:any =FormGroup ;
genders: any;
searchText:any;

@Input() item:string="";

detas=[
  {
  id:1, name:'Mr mice',country:'india'
},
{
  id:2, name:'Mr mana',country:'china'
},
{
  id:3, name:'Mr suc',country:'japan'
},
{
  id:4, name:'Mr poonam',country:'nepal'
}
,  {
  id:5, name:'Mr mansi',country:'bangladesh'
}


]

// time!:string;
// timeSubscription!:Subscription;
// time$:Observable<string> | undefined;
// timeSet=Observable<string>
  constructor() {

// this.testMothed();

   }

  ngOnInit(): void {

    // this.test();
    // this.reactiveForm = new FormGroup({
    // 'username': new FormControl(null),
    // 'email': new FormControl(null),
    // 'course': new FormControl('Angular'),
    // 'gender': new FormControl('male'),
   
    // })

// this.timeSubscription = timeInterval().Subscription<any>((time:any)=>{
//   this.time = time;
  
//   })

    // this.timeSet<any> = timeInterval();




  }


// test(){

//   alert("ngOnInit")

// }


  // onSubmit(){

  // console.log(this.reactiveForm)
  // }

// ngOnDestroy():void{
//   this.timeSubscription?.unsubscribe();
// }


// testMothed(){

//   alert('run')
// }
ngOnChanges(){

console.log("hello")
}


}
