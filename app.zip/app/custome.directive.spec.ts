import { CustomeDirective } from './custome.directive';

describe('CustomeDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomeDirective();
    expect(directive).toBeTruthy();
  });
});
