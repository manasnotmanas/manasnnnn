import { Component, OnInit } from '@angular/core';
import { FormControl,FormBuilder, Validators } from '@angular/forms';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss']
})
export class LoginFormComponent implements OnInit {
  loginForm: any;
  FormBuilder: any;

  data="Suchendra Singh";

  constructor( private formBuilder:FormBuilder,private service:ServiceService) { }
  displayedColumns: string[] = ['id', 'albumId', 'title', 'url','thumbnailUrl'];
  dataSource = [] 
  ngOnInit(): void {

    this.service.get('/posts').subscribe((data:any)=>{

      this.dataSource = data
      
        })

    this.loginForm =this.FormBuilder.group({
email: new FormControl('',[Validators.required,
Validators.pattern(
  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
),]
),
    password: new FormControl('',Validators.required)

    })
  }

  onLogin(){}



 


}
