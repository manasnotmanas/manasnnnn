import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-child-login',
  templateUrl: './child-login.component.html',
  styleUrls: ['./child-login.component.scss']
})
export class ChildLoginComponent implements OnInit {


  constructor() { }
 
  ngOnInit(): void {
  }

}
