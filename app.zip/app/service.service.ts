import { Injectable } from '@angular/core';
import {  map, Observable } from 'rxjs';
import { environment } from 'src/environments/environment.prod';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  http: any;

  // httpOptions: any= {
  //   observe: 'response',
    
  // };
  baseUrl = environment.apiUrl;


  constructor() { }


 

  // get(url: any): Observable<any> {
  //   return this.http.get(this.baseUrl + url);
    
  // }

  get(url:any): Observable<any> {
    return this.http.get(this.baseUrl +url).pipe(map(res => res));
  }

  
  post(url: any, data: any): Observable<any> {
    return this.http.post(this.baseUrl + url, data);
  }
 
  put(api: any, data: any): Observable<any> {
    console.log(this.baseUrl + api, data);
    return this.http.put(this.baseUrl + api, data);
  }
  
  del(url: any): Observable<any> {
  
    return this.http.delete(this.baseUrl + url);
  }
  








}
