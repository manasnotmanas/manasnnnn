import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustome]'
})
export class CustomeDirective {

  constructor(private el:ElementRef) { 
el.nativeElement.style.color="red"


  }

}
