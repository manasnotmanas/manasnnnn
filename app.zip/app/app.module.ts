import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule, } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignupComponent } from './signup/signup.component';

import { ReactiveFormsModule } from '@angular/forms';
import { LoginFormComponent } from './login-form/login-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

	
 
import { FormsModule } from '@angular/forms';
import { ChildLoginComponent } from './login-form/child-login/child-login.component';
import { CustomeDirective } from './custome.directive';
import { UsdInrPipe } from './pipes/usd-inr.pipe';
import { dashboardComponent } from './dashboard/dashboard.component';


@NgModule({
  declarations: [
AppComponent,
SignupComponent,
dashboardComponent,
LoginFormComponent,
ReactiveFormComponent,
ChildLoginComponent,
CustomeDirective,
UsdInrPipe
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    FormsModule,

 
    
    
  ],
  providers: [],
  bootstrap: [AppComponent],

})
export class AppModule { }
