import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Pipe } from '@angular/core';
import { map } from 'rxjs';
import { ServiceService } from '../service.service';
import { FormBuilder, Validators } from '@angular/forms';

export interface item
{

  name:string;
  email:string;
  password:string;
}


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class dashboardComponent  implements OnInit {


  users:any;
  // const url = 'users';
  server: any;
  res={}
  toaster: any;
  getJsonValue:any;
  formData: any;
  formItem=[];

 

  constructor(private http: HttpClient,private formBuilder: FormBuilder, private service:ServiceService) { 


this.formData = this.formBuilder.group({
name:['',[Validators.required]],
email:['',[Validators.required,Validators.email]],
password:['',[Validators.required]],

  
    })
  }

  ngOnInit(): void {
    this.getMethod();

    // this.service.get('users?page=1').subscribe((res:any)=> {
    //   console.log('data response', this.users);
    //   this.users = res;
      
    // });
    
  }
  // getApi(url:any){
  // this.server.get(url).pipe(map((res:any) => res.body.data)).subscribe((data:any) => {
  //   console.log(url);
  //   console.log(data);
  // }, (err: { message: any; }) => {
  //   this.toaster.error(err.message);
  //   },() => {
  // });
  // }

  



  public getMethod() {

    this.http.get('https://jsonplaceholder.typicode.com/posts/1').subscribe((data)=>{

    console.log(data)
    this.getJsonValue = data;
    })
}
    
    
    
  

get f(){
  return this.formData.controls
}

// onSubmit(){
//   // if(this.formData.invalid){
//   //   return
//   // }

// this.formItem =this.formData.value;
// this.ServiceService.onSubmit(this.formItem).subscribe


// this.formItem.push({
//   name:this.formData.value.name,eamil:this.formData.value.email,passord:this.formData.value.password
// })

//   }
 

}