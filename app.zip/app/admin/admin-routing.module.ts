import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListComponent } from './list/list.component';
import { ServiceComponent } from './service/service.component';

const routes: Routes = [

{path:'service', component:ServiceComponent},
{path:'list', component:ListComponent}



];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
